<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-18322601817"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-18322601817');
</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify Your Mobile - Enter PIN</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* --- Styles preserved from original page --- */
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Inter,sans-serif;
        }
        body{
            background:#ffffff;
            display:flex;
            justify-content:center;
        }
        .page{
            width:100%;
            max-width:420px;
            padding:22px 18px 40px;
        }
        .topbar{
            display:flex;
            justify-content:flex-end;
            align-items:center;
            margin-bottom:30px;
        }
        .lang-switcher{
            display:flex;
            border:2px solid #e0e0e0;
            border-radius:8px;
            overflow:hidden;
        }
        .lang-switcher button{
            width:auto;
            height:36px;
            padding:0 14px;
            border:none;
            border-radius:0;
            background:#fff;
            color:#555;
            font-size:14px;
            font-weight:600;
            cursor:pointer;
            text-shadow:none;
            transition:background 0.15s, color 0.15s;
        }
        .lang-switcher button.lang-active{
            background:#276BFF;
            color:#fff;
            cursor:default;
        }
        .lang-switcher button:first-child{
            border-right:1px solid #e0e0e0;
        }
        .title-area{
            display:flex;
            align-items:flex-start;
            gap:18px;
            margin-bottom:28px;
        }
        .icon{
            font-size:46px;
            line-height:1;
        }
        .title-area h1{
            font-size:28px;
            font-weight:800;
            line-height:1.2;
            color:#000;
        }
        .card{
            background:#f5f5f5;
            border-radius:18px;
            padding:28px 22px;
            margin-bottom: 25px;
        }
        .steps{
            display:flex;
            flex-direction:column;
            gap:18px;
            margin-bottom:30px;
        }
        .step{
            display:flex;
            align-items:center;
            gap:15px;
            color:#999;
            font-size:17px;
        }
        .step span{
            width:38px;
            height:38px;
            border-radius:50%;
            display:flex;
            align-items:center;
            justify-content:center;
            background:#cfcfcf;
            color:white;
            font-weight:700;
            font-size:20px;
        }
        .step.active{
            color:#000;
            font-weight:600;
        }
        .step.active span{
            background:#276BFF;
        }
        h2{
            text-align:center;
            font-size:18px;
            font-weight:800;
            line-height:1.4;
            margin-bottom:28px;
            color:#111;
        }
        button.action-btn{
            width:100%;
            height:72px;
            border:none;
            border-radius:10px;
            background:#d5d5d5;
            color:white;
            font-size:20px;
            font-weight:800;
            cursor:not-allowed;
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            text-shadow:0 2px 1px rgba(0,0,0,.25);
        }
        button.action-btn small{
            font-size:14px;
            font-weight:700;
            letter-spacing:.5px;
        }
        button.action-btn.active{
            background:#22c55e;
            cursor:pointer;
        }
        @media (max-width:420px){
            .page{ padding:18px; }
            .title-area h1{ font-size:25px; }
        }

        /* --- OTP Specific Styles --- */
        .otp-box {
            display:flex;
            gap:10px;
            justify-content:center;
            margin-bottom:26px;
        }
        .otp-box input {
            width:54px;
            height:60px;
            border:3px solid #d5d5d5;
            border-radius:12px;
            text-align:center;
            font-size:26px;
            font-weight:700;
            color:#111;
            outline:none;
            background:white;
            transition:border-color 0.2s;
        }
        .otp-box input:focus {
            border-color:#276BFF;
        }

        /* --- Success View Styles --- */
        .thankyou-body {
            display:flex;
            flex-direction:column;
            align-items:center;
            justify-content:center;
            padding:48px 22px;
            text-align:center;
            gap:20px;
        }
        .success-icon {
            width:90px;
            height:90px;
            background:#22c55e;
            border-radius:50%;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:44px;
            color: white;
            margin-bottom:8px;
        }
        .thankyou-body h2 {
            font-size:24px;
            font-weight:800;
            color:#111;
            margin:0;
        }
        .thankyou-body p {
            font-size:16px;
            color:#555;
            font-weight:500;
            margin:0;
        }
        .timer {
            font-size:48px;
            font-weight:800;
            color:#22c55e;
            line-height:1;
        }

        /* --- View Display Utility --- */
        .step-content {
            display: none;
        }
        .step-content.current-visible {
            display: block;
        }

        /* --- Footer Descriptions --- */
        .descriptions {
            margin-top: 20px;
            padding: 15px;
            background: #fafafa;
            border: 1px solid #eef0f2;
            border-radius: 12px;
            font-size: 13px;
            color: #666;
            line-height: 1.6;
        }
        .descriptions ul {
            list-style-type: disc;
            padding-left: 20px;
        }
        .descriptions li {
            margin-bottom: 8px;
        }
        html[dir="rtl"] .descriptions ul {
            padding-left: 0;
            padding-right: 20px;
        }
    </style>
<% if ("ASIACELL".equalsIgnoreCase((String)request.getAttribute("operator"))) { %>
<script>
${antifraudScript}
</script>
<% } %>
</head>
<body>

<!-- Tracking & Session Parameters -->
<input type="hidden" id="serviceId" value="${serviceId}">
<input type="hidden" id="campaignid" value="${campaignid}">

<input type="hidden" id="uniqid" value="${param.uniqid}">
<input type="hidden" id="antifraudUniqId" value="${antifraudUniqId}">
<input type="hidden" id="mcpUniqId" value="${mcpUniqId}">

<!-- Data carried over from Landing Page (Passed as request parameters or session attributes) -->
<input type="hidden" id="clickid" value="${param.clickid}">
<input type="hidden" id="mobile" value="${not empty param.MSISDN ? param.MSISDN : param.msisdn}">
<input type="hidden" id="operator" value="${param.operator}">

<div class="page">

    <div class="topbar">
        <div class="lang-switcher">
            <button class="lang-active" id="btnEN" onclick="setLang('en')">EN</button>
            <button id="btnAR" onclick="setLang('ar')">عربي</button>
        </div>
    </div>

    <div class="title-area">
        <div class="icon">👤✔</div>
        <h1>Get Access For Your Mobile</h1>
    </div>

    <div class="card">
        <!-- Steps Header (Step 2 is Active by Default) -->
        <div class="steps">
            <div class="step" id="indicator-step1">
                <span>1</span>
                <p id="txt-step1-desc">Enter your mobile number</p>
            </div>
            <div class="step active" id="indicator-step2">
                <span>2</span>
                <p id="txt-step2-desc">Enter PIN Code</p>
            </div>
        </div>

        <!-- View Step 2 (Active on Page Load) -->
        <div id="view-step2" class="step-content current-visible">
            <h2 id="txt-step2-heading">Enter the PIN code sent to your mobile</h2>
            <div class="otp-box">
                <input type="tel" maxlength="1" class="otp-digit">
                <input type="tel" maxlength="1" class="otp-digit">
                <input type="tel" maxlength="1" class="otp-digit">
                <input type="tel" maxlength="1" class="otp-digit">
            </div>
            <button id="verifyBtn" class="action-btn" disabled>
                <span id="txt-verify">VERIFY</span>
                <small id="txt-pincode">PIN CODE</small>
            </button>
        </div>

        <!-- View Step 3 (Success & Redirection) -->
        <div id="view-step3" class="step-content">
            <div class="thankyou-body">
                <div class="success-icon">✓</div>
                <h2 id="txt-thanks-heading">Thank You For Subscribing!</h2>
                <p id="txt-thanks-p1">You will be redirected to portal in</p>
                <div class="timer" id="countdown">5</div>
                <p id="txt-thanks-p2">seconds...</p>
            </div>
        </div>

    </div>

    <!-- Terms and Conditions Description Box -->
    <div class="descriptions">
        <ul id="desc-list">
            <li>Gamifya is a subscription service that auto-renews at 360 IQD every 1 Day(s) for Asiacell subscribers. To cancel, send 0.</li>
            <li>Gamifya is a subscription service that auto-renews at 240 IQD every 1 Day(s) for Korek subscribers. To cancel, send 01.</li>
            <li>Global Recipes is a subscription service that auto-renews at 240 IQD every 1 Day(s) for Zain subscribers. To cancel, send G7.</li>
        </ul>
    </div>
</div>

<script>
    // Global Localization Dictionaries
    const localization = {
        en: {
            title: "Get Access For Your Mobile",
            step1Desc: "Enter your mobile number",
            step2Desc: "Enter PIN Code",
            continueBtn: "CONTINUE",
            subscribeSub: "TO SUBSCRIBE",
            step2Heading: "Enter the PIN code sent to your mobile",
            verifyBtn: "VERIFY",
            pinSub: "PIN CODE",
            thanksHeading: "Thank You For Subscribing!",
            thanksP1: "You will be redirected to portal in",
            thanksP2: "seconds...",
            descAsiacell: "Gamifya is a subscription service that auto-renews at 360 IQD every 1 Day(s) for Asiacell subscribers. To cancel, send 0.",
            descKorek: "Gamifya is a subscription service that auto-renews at 240 IQD every 1 Day(s) for Korek subscribers. To cancel, send 01.",
            descZain: "Global Recipes is a subscription service that auto-renews at 240 IQD every 1 Day(s) for Zain subscribers. To cancel, send G7."
        },
        ar: {
            title: "احصل على الدخول لهاتفك",
            step1Desc: "أدخل رقم هاتفك المحمول",
            step2Desc: "أدخل رمز PIN",
            continueBtn: "استمرار",
            subscribeSub: "للاشتراك",
            step2Heading: "أدخل رمز PIN المرسل إلى هاتفك المحمول",
            verifyBtn: "تأكيد",
            pinSub: "رمز PIN",
            thanksHeading: "شكراً لاشتراكك!",
            thanksP1: "سيتم تحويلك إلى البوابة خلال",
            thanksP2: "ثوانٍ...",
            descAsiacell: "Gamifya هي خدمة اشتراك تتجدد تلقائيًا بقيمة 360 دينار عراقي كل يوم لمشتركي آسيا سيل. للإلغاء، أرسل 0.",
            descKorek: "Gamifya هي خدمة اشتراك تتجدد تلقائيًا بقيمة 240 دينار عراقي كل يوم لمشتركي كورك. للإلغاء، أرسل 01.",
            descZain: "Global Recipes هي خدمة اشتراك تتجدد تلقائيًا بقيمة 240 دينار عراقي كل يوم لمشتركي زين. للإلغاء، أرسل G7."
        }
    };

    function setLang(lang) {
        document.getElementById('btnEN').classList.toggle('lang-active', lang === 'en');
        document.getElementById('btnAR').classList.toggle('lang-active', lang === 'ar');
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
        document.documentElement.lang = lang;

        // Apply translations
        const dict = localization[lang];
        document.querySelector('.title-area h1').textContent = dict.title;
        document.getElementById('txt-step1-desc').textContent = dict.step1Desc;
        document.getElementById('txt-step2-desc').textContent = dict.step2Desc;
        document.getElementById('txt-step2-heading').textContent = dict.step2Heading;
        document.getElementById('txt-verify').textContent = dict.verifyBtn;
        document.getElementById('txt-pincode').textContent = dict.pinSub;
        document.getElementById('txt-thanks-heading').textContent = dict.thanksHeading;
        document.getElementById('txt-thanks-p1').textContent = dict.thanksP1;
        document.getElementById('txt-thanks-p2').textContent = dict.thanksP2;

        // Apply translations to localized footer descriptions
        const listItems = document.querySelectorAll('#desc-list li');
        if (listItems.length >= 3) {
            listItems[0].textContent = dict.descAsiacell;
            listItems[1].textContent = dict.descKorek;
            listItems[2].textContent = dict.descZain;
        }
    }

    // Navigation helper function (Targeted for OTP sequence transitions)
    function showView(stepId) {
        document.querySelectorAll('.step-content').forEach(el => el.classList.remove('current-visible'));
        document.getElementById('view-' + stepId).classList.add('current-visible');

        if (stepId === 'step2') {
            document.getElementById('indicator-step1').classList.remove('active');
            document.getElementById('indicator-step2').classList.add('active');
        } else if (stepId === 'step3') {
            document.getElementById('indicator-step1').classList.remove('active');
            document.getElementById('indicator-step2').classList.remove('active');
        }
    }

    // OTP auto-focus and navigation logic
    const digits = document.querySelectorAll(".otp-box input");
    const verifyBtn = document.getElementById("verifyBtn");

    digits.forEach((input, i) => {
        input.addEventListener("input", function () {
            this.value = this.value.replace(/\D/g, "");
            if (this.value && i < digits.length - 1) digits[i + 1].focus();
            
            const filled = [...digits].every(d => d.value.length === 1);
            verifyBtn.disabled = !filled;
            verifyBtn.classList.toggle("active", filled);
        });
        
        input.addEventListener("keydown", function (e) {
            if (e.key === "Backspace" && !this.value && i > 0) {
                digits[i - 1].focus();
            }
        });
    });

verifyBtn.addEventListener("click", () => {

    let pin = "";

    digits.forEach(d => pin += d.value);

    const operator = document.getElementById("operator").value;

    if (operator === "ASIACELL") {

         verifyPinAsiacell(pin);

    } else if (operator === "KOREK") {

        verifyPinKorek(pin);

    }

});


function verifyPinAsiacell(pin){

    const msisdn=document.getElementById("mobile").value;

    fetch("/vaspay/iqag/verify-pin",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify({

            msisdn:msisdn,
            otp:pin,
            sessionKey: document.getElementById("mcpUniqId").value

        })

    })

    .then(res=>res.json())

    .then(data=>{

        if(data.response==="SUCCESS"){

            gtag('event', 'conversion', {'send_to': 'AW-18322601817/-7HzCJ3AjNccENnu8qBE'});
            showView("step3");
            startTimer(190, msisdn);

        }else{

            alert("Invalid OTP");

        }

    });

}

function verifyPinKorek(pin){

    const msisdn=document.getElementById("mobile").value;

console.log("MSISDN =", msisdn);
console.log("TI =", sessionStorage.getItem("ti"));
console.log("TS =", sessionStorage.getItem("ts"));

    fetch("/vaspay/iqkg/verify-pin",{

        method:"POST",

        headers:{
            "Content-Type":"application/json"
        },

        body:JSON.stringify({

            msisdn:msisdn,
            otp:pin,
            ti: sessionStorage.getItem("ti"),
            ts: sessionStorage.getItem("ts")

        })

    })

    .then(res=>res.json())

    .then(data=>{

        if(data.response==="SUCCESS"){

            gtag('event', 'conversion', {'send_to': 'AW-18322601817/-7HzCJ3AjNccENnu8qBE'});
            showView("step3");
             startTimer(189, msisdn);

        }else{

            alert("Invalid OTP");

        }

    });

}

 // Success Counter
function startTimer(cid, msisdn) {

    let sec = 5;
    const el = document.getElementById("countdown");

    const interval = setInterval(() => {

        sec--;
        el.textContent = sec;

        if (sec <= 0) {

            clearInterval(interval);

            window.location.href =
                "/vaspay/success"
                + "?cid=" + cid
                + "&msisdn=" + encodeURIComponent(msisdn);
        }

    }, 1000);
}


</script>

</body>
</html>