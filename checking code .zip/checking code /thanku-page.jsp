<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html lang="en">

<head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-18322601817"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-18322601817');
</script>

<!-- Event snippet for Thank_You conversion page -->
<script>
  gtag('event', 'conversion', {
      'send_to': 'AW-18322601817/-7HzCJ3AjNccENnu8qBE'
  });
</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Subscription Success</title>

    <style>

        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial,sans-serif;
        }

        body{
            background:#b8ddb7;
            display:flex;
            justify-content:center;
            align-items:center;
            min-height:100vh;
            padding:20px;
        }

        .success-container{
            background:#fff;
            width:100%;
            max-width:400px;
            border-radius:10px;
            padding:30px 20px;
            text-align:center;
            box-shadow:0 2px 10px rgba(0,0,0,0.1);
        }

        .success-icon{
            font-size:60px;
            color:#42c15c;
            margin-bottom:15px;
        }

        .title{
            font-size:24px;
            color:#0056b3;
            margin-bottom:15px;
            font-weight:bold;
        }

        .message{
            font-size:15px;
            color:#555;
            line-height:1.6;
            margin-bottom:25px;
        }

        .btn{
            display:inline-block;
            background:#ff6a00;
            color:#fff;
            text-decoration:none;
            padding:12px 28px;
            border-radius:25px;
            font-size:15px;
            font-weight:bold;
        }

    </style>

</head>

<body>

<div class="success-container">

    <div class="success-icon">
        ✓
    </div>

    <div class="title">
        Subscription Successful
    </div>

    <div class="message">
        Your subscription has been activated successfully.
    </div>

  <a href="${redirectUrl}" class="btn">
    Go To Portal
</a>

</div>

</body>
</html>