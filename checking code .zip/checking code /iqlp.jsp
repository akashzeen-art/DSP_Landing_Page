<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-18322601817"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-18322601817');
</script>

<!-- Event snippet for Page view conversion page -->
<script>
  gtag('event', 'conversion', {
      'send_to': 'AW-18322601817/I9QqCP6NpdccENnu8qBE'
  });
</script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get Access For Your Mobile</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* --- Styles from style.css --- */
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Inter,sans-serif;
        }
        body{
            background:#ffffff;
            display:flex;
            justify-content:center;
        }
        .page{
            width:100%;
            max-width:420px;
            padding:22px 18px 40px;
        }
        .topbar{
            display:flex;
            justify-content:flex-end;
            align-items:center;
            margin-bottom:30px;
        }
        .lang-switcher{
            display:flex;
            border:2px solid #e0e0e0;
            border-radius:8px;
            overflow:hidden;
        }
        .lang-switcher button{
            width:auto;
            height:36px;
            padding:0 14px;
            border:none;
            border-radius:0;
            background:#fff;
            color:#555;
            font-size:14px;
            font-weight:600;
            cursor:pointer;
            text-shadow:none;
            transition:background 0.15s, color 0.15s;
        }
        .lang-switcher button.lang-active{
            background:#276BFF;
            color:#fff;
            cursor:default;
        }
        .lang-switcher button:first-child{
            border-right:1px solid #e0e0e0;
        }
        .title-area{
            display:flex;
            align-items:flex-start;
            gap:18px;
            margin-bottom:28px;
        }
        .icon{
            font-size:46px;
            line-height:1;
        }
        .title-area h1{
            font-size:28px;
            font-weight:800;
            line-height:1.2;
            color:#000;
        }
        .card{
            background:#f5f5f5;
            border-radius:18px;
            padding:28px 22px;
            margin-bottom: 25px;
        }
        h2{
            text-align:center;
            font-size:18px;
            font-weight:800;
            line-height:1.4;
            margin-bottom:28px;
            color:#111;
        }
        .phone-box{
            display:flex;
            align-items:center;
            background:white;
            border:3px solid #d5d5d5;
            border-radius:12px;
            overflow:hidden;
            height:64px;
            margin-bottom:26px;
            transition:border-color 0.2s;
        }
        .phone-box.typing{
            border-color:#22c55e;
        }
        .country{
            display:flex;
            align-items:center;
            padding:0 14px;
            border-right:2px solid #e8e8e8;
            background:#f9f9f9;
            gap:8px;
            height:100%;
            flex-shrink:0;
        }
        .country img{
            width:32px;
            border-radius:3px;
        }
        .country span{
            font-size:18px;
            font-weight:700;
            color:#222;
        }
        .phone-box input{
            flex:1;
            height:100%;
            border:none;
            outline:none;
            font-size:26px;
            padding:0 16px;
            color:#111;
            background:white;
            letter-spacing:2px;
        }
        .phone-box input::placeholder{
            color:#c6c6c6;
            letter-spacing:3px;
            font-size:22px;
        }
        button.action-btn{
            width:100%;
            height:72px;
            border:none;
            border-radius:10px;
            background:#d5d5d5;
            color:white;
            font-size:20px;
            font-weight:800;
            cursor:not-allowed;
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            text-shadow:0 2px 1px rgba(0,0,0,.25);
        }
        button.action-btn small{
            font-size:14px;
            font-weight:700;
            letter-spacing:.5px;
        }
        button.action-btn.active{
            background:#22c55e;
            cursor:pointer;
        }
        @media (max-width:420px){
            .page{ padding:18px; }
            .title-area h1{ font-size:25px; }
            .phone-box{ height:62px; }
        }

        /* --- Inline Styles from thankyou.html --- */
        .thankyou-body {
            display:flex;
            flex-direction:column;
            align-items:center;
            justify-content:center;
            padding:48px 22px;
            text-align:center;
            gap:20px;
        }
        .success-icon {
            width:90px;
            height:90px;
            background:#22c55e;
            border-radius:50%;
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:44px;
            color: white;
            margin-bottom:8px;
        }
        .thankyou-body h2 {
            font-size:24px;
            font-weight:800;
            color:#111;
            margin:0;
        }
        .thankyou-body p {
            font-size:16px;
            color:#555;
            font-weight:500;
            margin:0;
        }
        .timer {
            font-size:48px;
            font-weight:800;
            color:#22c55e;
            line-height:1;
        }

        /* --- Single-page conditional display utility --- */
        .step-content {
            display: none;
        }
        .step-content.current-visible {
            display: block;
        }

        /* --- Description Section Styles --- */
        .descriptions {
            margin-top: 20px;
            padding: 15px;
            background: #fafafa;
            border: 1px solid #eef0f2;
            border-radius: 12px;
            font-size: 13px;
            color: #666;
            line-height: 1.6;
        }
        .descriptions ul {
            list-style-type: disc;
            padding-left: 20px;
        }
        .descriptions li {
            margin-bottom: 8px;
        }
        html[dir="rtl"] .descriptions ul {
            padding-left: 0;
            padding-right: 20px;
        }

        /* --- Operator Popup Overlay --- */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.25s ease, visibility 0.25s ease;
        }
        .modal-overlay.show {
            opacity: 1;
            visibility: visible;
        }
        .modal-content {
            background: #ffffff;
            width: 90%;
            max-width: 360px;
            border-radius: 24px;
            border: 3px solid #1fa334;
            padding: 24px 20px;
            position: relative;
            box-shadow: 0px 8px 30px rgba(0, 0, 0, 0.3);
            text-align: center;
            transform: scale(0.85);
            transition: transform 0.25s ease;
        }
        .modal-overlay.show .modal-content {
            transform: scale(1);
        }
        .modal-close {
            position: absolute;
            top: 15px;
            right: 18px;
            font-size: 22px;
            font-weight: bold;
            color: #333;
            cursor: pointer;
            border: none;
            background: none;
            line-height: 1;
        }
        html[dir="rtl"] .modal-close {
            right: auto;
            left: 18px;
        }
        .modal-title {
            font-size: 24px;
            font-weight: 800;
            color: #000;
            margin-bottom: 20px;
            margin-top: 5px;
        }
        .operator-buttons {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .op-btn {
            width: 100%;
            height: 52px;
            border: none;
            border-radius: 26px;
            background: #19b319;
            color: #ffffff;
            font-size: 18px;
            font-weight: 700;
            text-transform: uppercase;
            cursor: pointer;
            transition: background 0.15s ease, transform 0.1s ease;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }
        .op-btn:hover {
            background: #159915;
        }
        .op-btn:active {
            transform: scale(0.98);
        }
    </style>

<script>
${antifraudScript}
</script>

<meta http-equiv="delegate-ch"
        content="sec-ch-ua ${trackingDomain};
                 sec-ch-ua-mobile ${trackingDomain};
                 sec-ch-ua-arch ${trackingDomain};
                 sec-ch-ua-model ${trackingDomain};
                 sec-ch-ua-platform ${trackingDomain};
                 sec-ch-ua-platform-version ${trackingDomain};
                 sec-ch-ua-bitness ${trackingDomain};
                 sec-ch-ua-full-version-list ${trackingDomain};
                 sec-ch-ua-full-version ${trackingDomain}" />

<script>
!function(w,d,o,n,c){
  w[o]=w[o]||function(){(w[o].q=w[o].q||[]).push(arguments)};
  var s=d.createElement(n),t=d.getElementsByTagName(n)[0];
  s.async=true;
  s.defer=true;
  s.src="${trackingDomain}/t/t.js";
  t.parentNode.insertBefore(s,t);
}(window,document,"maxconv","script");
</script>

<noscript>
  <link rel="stylesheet" href="${trackingDomain}/t/t.css?mc_ns=1"/>
</noscript>

</head>
<body>

<!-- Tracking Parameters -->
    <input type="hidden" id="serviceId" value="${serviceId}">
    <input type="hidden" id="clickid" value="${clickId}">
    <input type="hidden" id="campaignid" value="${campaignid}">

<input type="hidden" id="antifraudUniqId" value="${antifraudUniqId}">
<input type="hidden" id="mcpUniqId" value="${mcpUniqId}">
<input type="hidden" id="clickid" value="${clickid}">

<div class="page">

    <div class="topbar">
        <div class="lang-switcher">
            <button class="lang-active" id="btnEN" onclick="setLang('en')">EN</button>
            <button id="btnAR" onclick="setLang('ar')">عربي</button>
        </div>
    </div>

    <div class="title-area">
        <div class="icon">👤✔</div>
        <h1>Get Access For Your Mobile</h1>
    </div>

    <div class="card">

        <div id="view-step1" class="step-content current-visible">
            <h2 id="txt-step1-heading">Enter your mobile number to start download now</h2>
            <div class="phone-box">
                <div class="country">
                    <img src="https://flagcdn.com/w40/iq.png" alt="IQ">
                    <span>964</span>
                </div>
                <input id="mobile" maxlength="10" type="tel" placeholder="XXXXX XXXXX">
            </div>
            <button id="continueBtn" class="action-btn" disabled>
                <span id="txt-continue">CONTINUE</span>
                <small id="txt-subscribe">TO SUBSCRIBE</small>
            </button>
        </div>

        <div id="view-step3" class="step-content">
            <div class="thankyou-body">
                <div class="success-icon">✓</div>
                <h2 id="txt-thanks-heading">Thank You For Subscribing!</h2>
                <p id="txt-thanks-p1">You will be redirected to portal in</p>
                <div class="timer" id="countdown">5</div>
                <p id="txt-thanks-p2">seconds...</p>
            </div>
        </div>

    </div>

    <!-- Terms and Conditions Description Box -->
    <div class="descriptions">
        <ul id="desc-list">
            <li>Gamifya is a subscription service that auto-renews at 360 IQD every 1 Day(s) for Asiacell subscribers. To cancel, send 0.</li>
            <li>Gamifya is a subscription service that auto-renews at 240 IQD every 1 Day(s) for Korek subscribers. To cancel, send 01.</li>
            <li>Global Recipes is a subscription service that auto-renews at 240 IQD every 1 Day(s) for Zain subscribers. To cancel, send G7.</li>
        </ul>
    </div>
</div>

<!-- Operator Selection Modal (Popup) -->
<div id="operatorModal" class="modal-overlay">
    <div class="modal-content">
        <button class="modal-close" onclick="closeModal()">&times;</button>
        <div class="modal-title" id="txt-modal-title">Select Operator</div>
        <div class="operator-buttons">
            <button class="op-btn" onclick="selectOperator('ASIACELL')">Asiacell</button>
            <button class="op-btn" onclick="selectOperator('ZAIN')">Zain</button>
            <button class="op-btn" onclick="selectOperator('KOREK')">Korek</button>
        </div>
    </div>
</div>

<script>
    // Global Localization Dictionaries
    const localization = {
        en: {
            title: "Get Access For Your Mobile",
            step1Heading: "Enter your mobile number to start download now",
            continueBtn: "CONTINUE",
            subscribeSub: "TO SUBSCRIBE",
            thanksHeading: "Thank You For Subscribing!",
            thanksP1: "You will be redirected to portal in",
            thanksP2: "seconds...",
            modalTitle: "Select Operator",
            descAsiacell: "Gamifya is a subscription service that auto-renews at 360 IQD every 1 Day(s) for Asiacell subscribers. To cancel, send 0.",
            descKorek: "Gamifya is a subscription service that auto-renews at 240 IQD every 1 Day(s) for Korek subscribers. To cancel, send 01.",
            descZain: "Global Recipes is a subscription service that auto-renews at 240 IQD every 1 Day(s) for Zain subscribers. To cancel, send G7."
        },
        ar: {
            title: "احصل على الدخول لهاتفك",
            step1Heading: "أدخل رقم هاتفك المحمول لبدء التنزيل الآن",
            continueBtn: "استمرار",
            subscribeSub: "للاشتراك",
            thanksHeading: "شكراً لاشتراكك!",
            thanksP1: "سيتم تحويلك إلى البوابة خلال",
            thanksP2: "ثوانٍ...",
            modalTitle: "اختر المشغل",
            descAsiacell: "Gamifya هي خدمة اشتراك تتجدد تلقائيًا بقيمة 360 دينار عراقي كل يوم لمشتركي آسيا سيل. للإلغاء، أرسل 0.",
            descKorek: "Gamifya هي خدمة اشتراك تتجدد تلقائيًا بقيمة 240 دينار عراقي كل يوم لمشتركي كورك. للإلغاء، أرسل 01.",
            descZain: "Global Recipes هي خدمة اشتراك تتجدد تلقائيًا بقيمة 240 دينار عراقي كل يوم لمشتركي زين. للإلغاء، أرسل G7."
        }
    };

    function setLang(lang) {
        document.getElementById('btnEN').classList.toggle('lang-active', lang === 'en');
        document.getElementById('btnAR').classList.toggle('lang-active', lang === 'ar');
        document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
        document.documentElement.lang = lang;

        // Apply translations
        const dict = localization[lang];
        document.querySelector('.title-area h1').textContent = dict.title;
        document.getElementById('txt-step1-heading').textContent = dict.step1Heading;
        document.getElementById('txt-continue').textContent = dict.continueBtn;
        document.getElementById('txt-subscribe').textContent = dict.subscribeSub;
        document.getElementById('txt-thanks-heading').textContent = dict.thanksHeading;
        document.getElementById('txt-thanks-p1').textContent = dict.thanksP1;
        document.getElementById('txt-thanks-p2').textContent = dict.thanksP2;
        document.getElementById('txt-modal-title').textContent = dict.modalTitle;

        // Apply translations to localized footer descriptions
        const listItems = document.querySelectorAll('#desc-list li');
        if (listItems.length >= 3) {
            listItems[0].textContent = dict.descAsiacell;
            listItems[1].textContent = dict.descKorek;
            listItems[2].textContent = dict.descZain;
        }
    }

    // Navigation helper function
    function showView(stepId) {
        document.querySelectorAll('.step-content').forEach(el => el.classList.remove('current-visible'));
        document.getElementById('view-' + stepId).classList.add('current-visible');
    }

    // Step 1: Mobile Logic
    const mobileInput = document.getElementById("mobile");
    const continueBtn = document.getElementById("continueBtn");

    mobileInput.addEventListener("input", function () {
        this.value = this.value.replace(/\D/g, "");
        const phoneBox = document.querySelector(".phone-box");

        if (this.value.length > 0) {
            phoneBox.classList.add("typing");
        } else {
            phoneBox.classList.remove("typing");
        }

        if (this.value.length === 10) {
            continueBtn.disabled = false;
            continueBtn.classList.add("active");
        } else {
            continueBtn.disabled = true;
            continueBtn.classList.remove("active");
        }
    });

    // Intercept with Operator Popup
    continueBtn.addEventListener("click", () => {
        openModal();
    });

    // Popup Logic functions
    function openModal() {
        document.getElementById("operatorModal").classList.add("show");
    }

    function closeModal() {
        document.getElementById("operatorModal").classList.remove("show");
    }

function selectOperator(operator) {

    closeModal();

    const msisdn = "964" + document.getElementById("mobile").value;

    if (operator === "ASIACELL") {

        // Anti-fraud already loaded on page load
        sendPinAsiacell(msisdn);

    } else if (operator === "ZAIN") {

        // Shield already loaded on page load
        sendPinZain(msisdn);

    } else if (operator === "KOREK") {

        // Korek flow remains the same
        sendPinKorek(msisdn);

    }
}

    // Step 3: Redirect Timer Logic
    function startTimer() {
        let sec = 5;
        const el = document.getElementById("countdown");
        const interval = setInterval(() => {
            sec--;
            el.textContent = sec;
            if (sec <= 0) {
                clearInterval(interval);
                window.location.href = "https://example.com"; 
            }
        }, 1000);
    }


// Global variables
let zainPrepare = null;

/**
 * ASIACELL PREPARE API
 */



/**
 * ZAIN PREPARE (SHIELD API)
 */
function prepareZain(msisdn, clickId) {

    fetch("/vaspay/iqzain/prepare?clickId=" + encodeURIComponent(clickId))
        .then(response => response.json())
        .then(data => {

            console.log("ZAIN Prepare :", data);

            zainPrepare = data;

            sessionStorage.setItem("uniqid", data.uniqid);

            // Inject Shield Script
            if (data.source) {

                const script = document.createElement("script");
                script.text = data.source;
                document.head.appendChild(script);
            }

        })
        .catch(err => {
            console.error("Shield Error", err);
        });
}

function prepareKorekOtp(msisdn) {

    fetch("/vaspay/iqkg/antifraud?msisdn="
            + encodeURIComponent(msisdn))

    .then(res => res.json())

    .then(data => {

        console.log("KOREK Antifraud:", data);

        sessionStorage.setItem("ti", data.ti);
        sessionStorage.setItem("ts", data.ts);

        if (data.script) {
            const script = document.createElement("script");
            script.text = data.script;
            document.head.appendChild(script);
        }

        window.location.href =
            "/vaspay/iqotp"
            + "?operator=KOREK"
            + "&msisdn=" + encodeURIComponent(msisdn);

    });

}


/**
 * ASIACELL SEND PIN
 */
function sendPinAsiacell(msisdn) {

console.log("SessionKey =", document.getElementById("antifraudUniqId").value);
console.log("ClickId =", document.getElementById("clickid").value);
console.log("McpUniqId =", document.getElementById("mcpUniqId").value);

    fetch("/vaspay/iqag/send-pin", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            msisdn: msisdn,
            // Per document Step 2: sessionKey must be antifrauduniqid
            sessionKey: document.getElementById("antifraudUniqId").value
        })
    })
    .then(response => response.json())
    .then(data => {

        console.log("Send PIN :", data);

        if (data.response === "SUCCESS") {
            // Per document Step 2: Pass mcpUniqId as uniqid and MSISDN to OTP Page URL
            const clickId = document.getElementById("clickid").value;
            window.location.href =
                "/vaspay/iqotp"
                + "?operator=ASIACELL"
                + "&MSISDN=" + encodeURIComponent(msisdn)
                + "&clickid=" + encodeURIComponent(clickId)
                + "&uniqid=" + encodeURIComponent(document.getElementById("mcpUniqId").value)
                + "&antifraudUniqId=" + encodeURIComponent(document.getElementById("antifraudUniqId").value);

        } else {
            alert(data.errorMessage || "Failed to send PIN");
        }
    })
    .catch(err => {
        console.error("Send PIN API Error", err);
    });
}


/**
 * ZAIN SEND PIN
 */
function sendPinZain(msisdn) {

    fetch("/vaspay/iqzain/send-pin", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            msisdn: msisdn,

        })

    })
    .then(response => response.json())
    .then(data => {

        console.log("ZAIN Send PIN :", data);

        if (data.response === "SUCCESS") {

           window.location.href =
               "/vaspay/iqzainotp"
                + "?operator=ZAIN"
                + "&msisdn=" + encodeURIComponent(msisdn)

        } else {

            alert(data.errorMessage);

        }

    });

}


/**
 * KOREK SEND PIN
 */
function sendPinKorek(msisdn) {

    fetch("/vaspay/iqkg/send-pin", {

        method: "POST",

        headers: {
            "Content-Type": "application/json"
        },

        body: JSON.stringify({

            msisdn: msisdn,

        })

    })
    .then(response => response.json())
    .then(data => {

        console.log("KOREK Send PIN :", data);

        if (data.response === "SUCCESS") {

            prepareKorekOtp(msisdn);

        } else {

            alert(data.errorMessage);

        }

    });

}
</script>

</body>
</html>